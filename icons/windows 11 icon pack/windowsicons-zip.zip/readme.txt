﻿=== Windows 11 Icon Set ===

By: ┏(＾0＾)┛liyanado graphic davinci┗(＾0＾) ┓ (http://www.rw-designer.com/user/97595)

Download: http://www.rw-designer.com/icon-set/windowsicons-zip

Author's description:

In this pack I have include windows 11 icons in the next pack I'll include the other icons too enjoy the icons bye

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.